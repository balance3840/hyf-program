#!/bin/bash
# Git Workshop Challenge Verification Script
# Usage: bash check.sh <level>

LEVEL="$1"

if [ -z "$LEVEL" ] || [ "$LEVEL" -lt 1 ] 2>/dev/null || [ "$LEVEL" -gt 6 ] 2>/dev/null; then
  echo "Usage: bash check.sh <level>"
  echo "  level: 1-6"
  exit 1
fi

pass() { echo "PASS: Level $LEVEL - $1"; exit 0; }
fail() { echo "FAIL: Level $LEVEL - $1"; exit 1; }

case "$LEVEL" in
  1)
    BRANCH=$(git symbolic-ref --short HEAD 2>/dev/null || echo "")
    if [ "$BRANCH" = "main" ]; then
      pass "You are on the main branch!"
    else
      fail "Not on main branch. Current: ${BRANCH:-detached HEAD}"
    fi
    ;;
  2)
    if ! git rev-parse --verify feature/user-profile >/dev/null 2>&1; then
      fail "Branch feature/user-profile not found"
    fi
    MERGE_COMMITS=$(git log --merges --oneline feature/user-profile 2>/dev/null | head -5)
    if [ -z "$MERGE_COMMITS" ]; then
      fail "No merge commit found on feature/user-profile"
    fi
    CONFLICTS=$(git diff feature/user-profile -- "*.js" "*.html" "*.css" 2>/dev/null | grep -c "<<<<<<" || true)
    if [ "$CONFLICTS" -gt 0 ]; then
      fail "Conflict markers still present in files"
    fi
    pass "Merge completed successfully on feature/user-profile!"
    ;;
  3)
    if ! git rev-parse --verify feature/api-refactor >/dev/null 2>&1; then
      fail "Branch feature/api-refactor not found"
    fi
    MAIN_TIP=$(git rev-parse main 2>/dev/null)
    IS_ANCESTOR=$(git merge-base --is-ancestor "$MAIN_TIP" feature/api-refactor 2>/dev/null && echo "yes" || echo "no")
    if [ "$IS_ANCESTOR" = "yes" ]; then
      pass "feature/api-refactor is rebased on top of main!"
    else
      fail "feature/api-refactor has not been rebased onto main"
    fi
    ;;
  4)
    if ! git rev-parse --verify feature/payments >/dev/null 2>&1; then
      fail "Branch feature/payments not found"
    fi
    MAIN_TIP=$(git rev-parse main 2>/dev/null)
    PAYMENT_COMMITS=$(git log --oneline feature/payments --not main 2>/dev/null | wc -l | tr -d " ")
    if [ "$PAYMENT_COMMITS" -ge 3 ]; then
      pass "feature/payments has $PAYMENT_COMMITS commits — all recovered!"
    else
      fail "feature/payments has only $PAYMENT_COMMITS commit(s), expected 3+"
    fi
    ;;
  5)
    if ! git rev-parse --verify feature/notifications >/dev/null 2>&1; then
      fail "Branch feature/notifications not found"
    fi
    NOTIF_COMMITS=$(git log --oneline feature/notifications --not main 2>/dev/null | wc -l | tr -d " ")
    if [ "$NOTIF_COMMITS" -ge 2 ] && [ "$NOTIF_COMMITS" -le 3 ]; then
      HAS_CONVENTIONAL=$(git log --oneline feature/notifications --not main 2>/dev/null | grep -cE "^[a-f0-9]+ (feat|fix|refactor|test|docs|chore):" || true)
      if [ "$HAS_CONVENTIONAL" -ge 2 ]; then
        pass "feature/notifications cleaned up to $NOTIF_COMMITS well-named commits!"
      else
        fail "Commits lack conventional prefixes (feat:, fix:, etc.)"
      fi
    else
      fail "feature/notifications has $NOTIF_COMMITS commits, expected 2-3"
    fi
    ;;
  6)
    REVERT_EXISTS=$(git log --oneline main 2>/dev/null | grep -ci "revert" || true)
    if [ "$REVERT_EXISTS" -ge 1 ]; then
      pass "Revert commit found on main — bug has been fixed!"
    else
      fail "No revert commit found on main branch"
    fi
    ;;
esac
