var assert = require("assert");
var fs = require("fs");
var path = require("path");

var DATA_DIR = path.join(__dirname, "..", "data");
var DATA_FILE = path.join(DATA_DIR, "tasks.json");

function cleanup() {
  if (fs.existsSync(DATA_FILE)) fs.unlinkSync(DATA_FILE);
}

var passed = 0;
var failed = 0;

function test(name, fn) {
  cleanup();
  try { fn(); passed++; console.log("  PASS: " + name); }
  catch (e) { failed++; console.error("  FAIL: " + name); console.error("    " + e.message); }
}

console.log("Running Integration Tests...\n");

test("full workflow: add, complete, archive", function() {
  var tm = require("../js/taskManager");
  var task = tm.addTask("Integration test", "high");
  tm.completeTask(task.id);
  tm.archiveTask(task.id);
  assert.strictEqual(tm.listTasks().length, 0);
  assert.strictEqual(tm.listArchived().length, 1);
});

test("search only finds non-archived tasks", function() {
  var tm = require("../js/taskManager");
  var t1 = tm.addTask("Find me", "low");
  var t2 = tm.addTask("Find me too", "high");
  tm.archiveTask(t2.id);
  assert.strictEqual(tm.searchTasks("find").length, 1);
});

cleanup();
console.log("\nResults: " + passed + " passed, " + failed + " failed\n");
process.exit(failed > 0 ? 1 : 0);
