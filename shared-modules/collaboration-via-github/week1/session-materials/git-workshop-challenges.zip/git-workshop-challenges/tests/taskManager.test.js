var assert = require("assert");
var fs = require("fs");
var path = require("path");

var DATA_DIR = path.join(__dirname, "..", "data");
var DATA_FILE = path.join(DATA_DIR, "tasks.json");

function cleanup() {
  if (fs.existsSync(DATA_FILE)) fs.unlinkSync(DATA_FILE);
  var csvFile = path.join(__dirname, "..", "test-export.csv");
  if (fs.existsSync(csvFile)) fs.unlinkSync(csvFile);
}

var passed = 0;
var failed = 0;

function test(name, fn) {
  cleanup();
  try { fn(); passed++; console.log("  PASS: " + name); }
  catch (e) { failed++; console.error("  FAIL: " + name); console.error("    " + e.message); }
}

console.log("Running Task Manager Tests...\n");

test("addTask creates a task with correct fields", function() {
  var tm = require("../js/taskManager");
  var task = tm.addTask("Test task", "high");
  assert.strictEqual(task.title, "Test task");
  assert.strictEqual(task.priority, "high");
  assert.strictEqual(task.status, "pending");
});

test("addTask rejects invalid priority", function() {
  var tm = require("../js/taskManager");
  assert.throws(function() { tm.addTask("Bad", "urgent"); });
});

test("listTasks returns all tasks", function() {
  var tm = require("../js/taskManager");
  tm.addTask("One", "low"); tm.addTask("Two", "high");
  assert.strictEqual(tm.listTasks().length, 2);
});

test("completeTask changes status to completed", function() {
  var tm = require("../js/taskManager");
  var task = tm.addTask("Complete me", "medium");
  assert.strictEqual(tm.completeTask(task.id).status, "completed");
});

test("deleteTask removes the task", function() {
  var tm = require("../js/taskManager");
  var task = tm.addTask("Delete me", "low");
  tm.deleteTask(task.id);
  assert.strictEqual(tm.listTasks().length, 0);
});

test("deleteTask throws for non-existent id", function() {
  var tm = require("../js/taskManager");
  assert.throws(function() { tm.deleteTask(9999); });
});

test("filterByStatus returns only tasks matching the given status", function() {
  var tm = require("../js/taskManager");
  var utils = require("../js/utils");
  tm.addTask("Pending task", "low");
  var t2 = tm.addTask("Done task", "high");
  tm.completeTask(t2.id);
  tm.addTask("Another pending", "medium");
  var allTasks = tm.listTasks();
  var completed = utils.filterByStatus(allTasks, "completed");
  var pending = utils.filterByStatus(allTasks, "pending");
  assert.strictEqual(completed.length, 1, "Expected 1 completed task, got " + completed.length);
  assert.strictEqual(pending.length, 2, "Expected 2 pending tasks, got " + pending.length);
});

test("searchTasks finds matching tasks", function() {
  var tm = require("../js/taskManager");
  tm.addTask("Buy groceries", "high"); tm.addTask("Buy supplies", "low"); tm.addTask("Clean house", "medium");
  assert.strictEqual(tm.searchTasks("buy").length, 2);
});

test("sortByPriority orders tasks by priority", function() {
  var utils = require("../js/utils");
  var tasks = [{ id: 1, priority: "low" }, { id: 2, priority: "high" }, { id: 3, priority: "medium" }];
  var sorted = utils.sortByPriority(tasks);
  assert.strictEqual(sorted[0].priority, "high");
  assert.strictEqual(sorted[2].priority, "low");
});

test("archiveTask hides task from listing", function() {
  var tm = require("../js/taskManager");
  var task = tm.addTask("Archive me", "low");
  tm.archiveTask(task.id);
  assert.strictEqual(tm.listTasks().length, 0);
});

test("exportToCsv creates a CSV file", function() {
  var tm = require("../js/taskManager");
  var exp = require("../js/export");
  tm.addTask("CSV task", "high");
  var tasks = tm.listTasks();
  var csvPath = path.join(__dirname, "..", "test-export.csv");
  var result = exp.exportToCsv(tasks, csvPath);
  assert.strictEqual(result.count, 1);
  assert.ok(fs.existsSync(csvPath));
});

cleanup();
console.log("\nResults: " + passed + " passed, " + failed + " failed\n");
process.exit(failed > 0 ? 1 : 0);
