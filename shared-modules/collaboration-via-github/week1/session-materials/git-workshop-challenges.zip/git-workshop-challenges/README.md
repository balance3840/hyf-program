# Git Workshop: Rescue Mission & Detective Challenge

> You have just joined a new development team. On your first day, you discover
> the repository is in complete chaos. A developer left in a hurry, leaving
> behind broken branches, lost commits, messy history, and a mysterious bug
> hiding somewhere in the code. Your mission: fix everything.

## Getting Started

Run `git status`. Something is wrong. That is your first challenge.

After solving Level 1, use `bash check.sh <level>` to verify each solution.

## The Challenges

### Level 1: Detached HEAD (10 points) — Easy
You are in a "detached HEAD" state at an old commit.
**Goal**: Get back onto the main branch.
**Verify**: `bash check.sh 1`

### Level 2: Merge Conflicts (20 points) — Medium
The `feature/user-profile` branch needs to be merged with main.
**Goal**: Checkout the branch, merge main into it, resolve all conflicts.
**Verify**: `bash check.sh 2`

### Level 3: Diverged Branches (30 points) — Medium
The `feature/api-refactor` branch has diverged from main.
**Goal**: Rebase the feature branch onto main (do NOT merge).
**Verify**: `bash check.sh 3`

### Level 4: Lost Commits (40 points) — Hard
The `feature/payments` branch lost 2 commits after an accidental force push.
**Goal**: Recover the lost commits using reflog and cherry-pick.
**Verify**: `bash check.sh 4`

### Level 5: Messy History (40 points) — Hard
The `feature/notifications` branch has 8 messy commits.
**Goal**: Clean up into 2-3 well-named commits using interactive rebase.
**Verify**: `bash check.sh 5`

### Level 6: Detective — Find the Bug (60 points) — Expert
A subtle bug was introduced somewhere in the **main branch** commit history.
The "Filter by status" dropdown in the app is broken — try filtering by
"Completed" or "Pending" and notice the wrong tasks appear.
**Goal**: Use `git bisect` to find the guilty commit, then revert it.
**Hint**: Open `index.html` in a browser, add some tasks, complete a few,
then use the status filter to see the bug in action.
**Verify**: `bash check.sh 6`

## Scoring

| Level | Points | Difficulty |
|-------|--------|------------|
| 1     | 10     | Easy       |
| 2     | 20     | Medium     |
| 3     | 30     | Medium     |
| 4     | 40     | Hard       |
| 5     | 40     | Hard       |
| 6     | 60     | Expert     |
| **Total** | **200** | |

**Bonus**: +10 points for each level completed in under 5 minutes.

## Team Rules: Driver Rotation

You work as a team on **one computer**. One person types (the **Driver**),
the rest guide and discuss (the **Navigators**).

**How it works**:
1. Pick a Driver for Level 1
2. The Driver is the only one who touches the keyboard
3. Navigators discuss, suggest commands, and help — but do NOT type
4. **Rotate the Driver after each level** — everyone gets a turn
5. If a level takes more than 10 minutes, rotate mid-level

**Why?** Git mistakes are scary alone but fun to debug together.
Talking through each command before typing it is how you actually learn.

**Golden rule**: The Driver must type what the team agrees on.
No solo heroics!

## Running Tests

```bash
node tests/taskManager.test.js
```

## The App

This is a simple web-based task manager. Open `index.html` in a browser.
