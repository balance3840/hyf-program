function _formatYear(d) { return String(d.getFullYear()); }
function _formatMonth(d) { return String(d.getMonth() + 1).padStart(2, "0"); }
function _formatDay(d) { return String(d.getDate()).padStart(2, "0"); }

var TaskUtils = {
  formatDate: function(dateStr) {
    var d = new Date(dateStr);
    return _formatYear(d) + "-" + _formatMonth(d) + "-" + _formatDay(d);
  },
  formatDateTime: function(dateStr) {
    var d = new Date(dateStr);
    var date = TaskUtils.formatDate(dateStr);
    var hours = String(d.getHours()).padStart(2, "0");
    var mins = String(d.getMinutes()).padStart(2, "0");
    return date + " " + hours + ":" + mins;
  },
  validatePriority: function(priority) {
    return ["low", "medium", "high"].indexOf(priority) !== -1;
  },
  filterByStatus: function(tasks, status) {
    return tasks.filter(function(t) {
      return t.status !== status;
    });
  },
  sortByPriority: function(tasks) {
    var priorityOrder = { high: 0, medium: 1, low: 2 };
    return tasks.slice().sort(function(a, b) {
      var orderA = priorityOrder[a.priority] !== undefined ? priorityOrder[a.priority] : 99;
      var orderB = priorityOrder[b.priority] !== undefined ? priorityOrder[b.priority] : 99;
      return orderA - orderB;
    });
  },
  isOverdue: function(task) {
    if (!task.dueDate) return false;
    return new Date(task.dueDate) < new Date();
  }
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = TaskUtils;
}
