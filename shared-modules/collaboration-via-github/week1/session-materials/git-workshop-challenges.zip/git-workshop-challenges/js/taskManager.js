(function() {
  var storage = (typeof module !== "undefined" && module.exports)
    ? require("./storage") : TaskStorage;

  function findTask(data, id) {
    for (var i = 0; i < data.tasks.length; i++) {
      if (data.tasks[i].id === id) return data.tasks[i];
    }
    return null;
  }

  var TaskManager = {
    addTask: function(title, priority, dueDate) {
      if (!title || typeof title !== "string") throw new Error("Title is required and must be a string");
      if (["low", "medium", "high"].indexOf(priority) === -1) throw new Error("Priority must be low, medium, or high");
      var data = storage.loadTasks();
      var task = {
        id: data.nextId, title: title.trim(), priority: priority,
        status: "pending", createdAt: new Date().toISOString(),
        dueDate: dueDate || null, archived: false, tags: []
      };
      data.tasks.push(task);
      data.nextId = data.nextId + 1;
      storage.saveTasks(data);
      return task;
    },
    listTasks: function() {
      return storage.loadTasks().tasks.filter(function(t) { return !t.archived; });
    },
    listArchived: function() {
      return storage.loadTasks().tasks.filter(function(t) { return t.archived === true; });
    },
    deleteTask: function(id) {
      var data = storage.loadTasks();
      var idx = -1;
      for (var i = 0; i < data.tasks.length; i++) { if (data.tasks[i].id === id) { idx = i; break; } }
      if (idx === -1) throw new Error("Task not found with id: " + id);
      var removed = data.tasks.splice(idx, 1)[0];
      storage.saveTasks(data);
      return removed;
    },
    completeTask: function(id) {
      var data = storage.loadTasks();
      var task = findTask(data, id);
      if (!task) throw new Error("Task not found with id: " + id);
      task.status = "completed";
      storage.saveTasks(data);
      return task;
    },
    searchTasks: function(query) {
      var lq = query.toLowerCase();
      return storage.loadTasks().tasks.filter(function(t) {
        return !t.archived && t.title.toLowerCase().indexOf(lq) !== -1;
      });
    },
    editTask: function(id, updates) {
      var data = storage.loadTasks();
      var task = findTask(data, id);
      if (!task) throw new Error("Task not found with id: " + id);
      if (updates.title) task.title = updates.title.trim();
      if (updates.priority) {
        if (["low", "medium", "high"].indexOf(updates.priority) === -1) throw new Error("Invalid priority");
        task.priority = updates.priority;
      }
      if (updates.dueDate !== undefined) task.dueDate = updates.dueDate;
      if (updates.tags) task.tags = updates.tags;
      storage.saveTasks(data);
      return task;
    },
    archiveTask: function(id) {
      var data = storage.loadTasks();
      var task = findTask(data, id);
      if (!task) throw new Error("Task not found with id: " + id);
      task.archived = true;
      storage.saveTasks(data);
      return task;
    },
    getStats: function(tasks) {
      var bp = { low: 0, medium: 0, high: 0 };
      var bs = { pending: 0, completed: 0 };
      tasks.forEach(function(t) {
        if (bp[t.priority] !== undefined) bp[t.priority]++;
        if (bs[t.status] !== undefined) bs[t.status]++;
      });
      return { total: tasks.length, byPriority: bp, byStatus: bs };
    }
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = TaskManager;
  } else {
    window.TaskManager = TaskManager;
  }
})();
