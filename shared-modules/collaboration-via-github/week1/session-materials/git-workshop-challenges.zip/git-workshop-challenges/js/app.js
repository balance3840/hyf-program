(function() {
  var form = document.getElementById("task-form");
  var titleInput = document.getElementById("task-title");
  var prioritySelect = document.getElementById("task-priority");
  var listEl = document.getElementById("task-list-items");
  var searchInput = document.getElementById("search-input");
  var statsEl = document.getElementById("stats-content");
  var statusFilter = document.getElementById("status-filter");

  function renderTasks(tasks) {
    if (!tasks) tasks = TaskManager.listTasks();
    if (!tasks || tasks.length === 0) {
      listEl.innerHTML = "<p class=\"empty-state\">No tasks yet. Use the form above to add your first task!</p>";
      renderStats();
      return;
    }
    var html = "";
    for (var i = 0; i < tasks.length; i++) {
      var t = tasks[i];
      var cls = t.status === "completed" ? "task-item completed" : "task-item";
      html += "<div class=\"" + cls + "\" data-id=\"" + t.id + "\">";
      html += "<input type=\"checkbox\"" + (t.status === "completed" ? " checked" : "") + ">";
      html += "<span class=\"title\">" + t.title + "</span>";
      html += "<span class=\"priority priority-" + t.priority + "\">" + t.priority + "</span>";
      html += "<button class=\"delete-btn\">Delete</button>";
      html += "</div>";
    }
    listEl.innerHTML = html;
    renderStats();
  }

  function renderStats() {
    if (!statsEl) return;
    var tasks = TaskManager.listTasks();
    if (!tasks || tasks.length === 0) {
      statsEl.innerHTML = "<p>No tasks to show statistics for.</p>";
      return;
    }
    var stats = TaskManager.getStats(tasks);
    statsEl.innerHTML = "<p>Total: " + stats.total +
      " | Pending: " + stats.byStatus.pending +
      " | Completed: " + stats.byStatus.completed + "</p>" +
      "<p>High: " + stats.byPriority.high +
      " | Medium: " + stats.byPriority.medium +
      " | Low: " + stats.byPriority.low + "</p>";
  }

  function validateTitle(title) {
    if (!title || title.trim().length === 0) return false;
    if (title.trim().length < 2) return false;
    return true;
  }

  form.addEventListener("submit", function(e) {
    e.preventDefault();
    var title = titleInput.value;
    if (!validateTitle(title)) {
      titleInput.classList.add("input-error");
      return;
    }
    titleInput.classList.remove("input-error");
    TaskManager.addTask(title.trim(), prioritySelect.value);
    titleInput.value = "";
    renderTasks();
  });

  if (searchInput) {
    searchInput.addEventListener("input", function() {
      var q = searchInput.value.trim();
      if (q.length === 0) { renderTasks(); return; }
      renderTasks(TaskManager.searchTasks(q));
    });
  }

  if (statusFilter) {
    statusFilter.addEventListener("change", function() {
      var val = statusFilter.value;
      if (val === "all") { renderTasks(); return; }
      var tasks = TaskManager.listTasks();
      renderTasks(TaskUtils.filterByStatus(tasks, val));
    });
  }

  listEl.addEventListener("click", function(e) {
    if (e.target.classList.contains("delete-btn")) {
      var item = e.target.closest(".task-item");
      if (!item) return;
      TaskManager.deleteTask(parseInt(item.dataset.id));
      renderTasks();
    }
  });

  listEl.addEventListener("change", function(e) {
    if (e.target.type === "checkbox") {
      var item = e.target.closest(".task-item");
      if (!item) return;
      TaskManager.completeTask(parseInt(item.dataset.id));
      renderTasks();
    }
  });

  renderTasks();
})();
