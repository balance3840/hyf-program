var TaskStorage = (function() {
  var isBrowser = typeof window !== "undefined";

  function ensureValidData(data) {
    if (!data || !data.tasks || !Array.isArray(data.tasks)) {
      return { tasks: [], nextId: 1 };
    }
    var maxId = 0;
    for (var i = 0; i < data.tasks.length; i++) {
      if (data.tasks[i].id > maxId) maxId = data.tasks[i].id;
    }
    if (!data.nextId || data.nextId <= maxId) {
      data.nextId = maxId + 1;
    }
    return data;
  }

  if (isBrowser) {
    return {
      loadTasks: function() {
        try {
          var raw = localStorage.getItem("taskManagerData");
          if (!raw) return { tasks: [], nextId: 1 };
          return ensureValidData(JSON.parse(raw));
        } catch (e) { return { tasks: [], nextId: 1 }; }
      },
      saveTasks: function(data) {
        localStorage.setItem("taskManagerData", JSON.stringify(data));
      }
    };
  }

  var fs = require("fs");
  var path = require("path");
  var DATA_DIR = path.join(__dirname, "..", "data");
  var DATA_FILE = path.join(DATA_DIR, "tasks.json");

  return {
    loadTasks: function() {
      try {
        if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
        if (!fs.existsSync(DATA_FILE)) return { tasks: [], nextId: 1 };
        return ensureValidData(JSON.parse(fs.readFileSync(DATA_FILE, "utf-8")));
      } catch (e) { return { tasks: [], nextId: 1 }; }
    },
    saveTasks: function(data) {
      if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
      fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
    }
  };
})();

if (typeof module !== "undefined" && module.exports) {
  module.exports = TaskStorage;
}
