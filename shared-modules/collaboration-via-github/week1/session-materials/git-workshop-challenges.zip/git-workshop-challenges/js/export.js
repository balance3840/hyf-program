var fs = (typeof require === "function" && typeof window === "undefined") ? require("fs") : null;

var TaskExport = {
  exportToCsv: function(tasks, filepath) {
    if (!filepath) throw new Error("File path is required for export");
    var header = "id,title,priority,status,createdAt";
    var rows = tasks.map(function(t) {
      return t.id + ",\"" + t.title + "\"," + t.priority + "," + t.status + "," + t.createdAt;
    });
    var csv = header + "\n" + rows.join("\n") + "\n";
    if (fs) { fs.writeFileSync(filepath, csv, "utf-8"); }
    return { count: tasks.length, path: filepath };
  },
  importFromJson: function(filepath) {
    if (!fs) throw new Error("Import only available in Node.js");
    if (!fs.existsSync(filepath)) throw new Error("File not found: " + filepath);
    var raw = fs.readFileSync(filepath, "utf-8");
    var data = JSON.parse(raw);
    if (!Array.isArray(data)) throw new Error("Expected an array of tasks");
    return data;
  }
};

if (typeof module !== "undefined" && module.exports) {
  module.exports = TaskExport;
}
