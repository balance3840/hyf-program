# Contributing to Task Manager

## Getting Started
1. Clone this repository
2. Open `index.html` in your browser
3. Make your changes

## Code Style
- Use vanilla JavaScript (no frameworks)
- Use double quotes for strings
- Add tests for new features

## Testing
```bash
node tests/taskManager.test.js
```

## Pull Requests
- Create a feature branch from main
- Write descriptive commit messages using conventional commits
- Ensure all tests pass before submitting
