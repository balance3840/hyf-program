# Git Workshop Challenges — Solutions Guide

> FOR INSTRUCTORS ONLY. Do not share with participants.

## Level 1: Detached HEAD (10 points)

**Problem**: The repo is in a detached HEAD state.

**Solution**:
```bash
git checkout main
# or
git switch main
```

**Why it works**: `git checkout main` moves HEAD to point at the main branch ref instead of a specific commit.

**Common mistakes**:
- Creating a new branch from the detached state instead of switching to main
- Using `git checkout -b main` which would try to create a new branch named main

---

## Level 2: Stuck Mid-Merge (20 points)

**Problem**: feature/user-profile needs to be merged with main, but there are conflicts.

**Solution**:
```bash
git checkout feature/user-profile
git merge main
# Resolve conflicts in js/app.js and index.html
# Edit files to combine both sides' changes
git add js/app.js index.html
git commit -m "merge: integrate main into user-profile"
```

**Why it works**: The branch has commits that modify the same files main later changed. Merging creates conflicts that must be manually resolved.

**Common mistakes**:
- Using `git merge --abort` to give up
- Only keeping one side of the conflict
- Leaving conflict markers (<<<<<<) in files

---

## Level 3: Diverged Branches (30 points)

**Problem**: feature/api-refactor has diverged from main.

**Solution**:
```bash
git checkout feature/api-refactor
git rebase main
# Resolve any conflicts during rebase
git add .
git rebase --continue
```

**Why it works**: Rebase replays the branch's commits on top of main's latest, creating a linear history.

**Common mistakes**:
- Using `git merge` instead of `git rebase`
- Forgetting `git rebase --continue` after resolving conflicts
- Not resolving all conflicts before continuing

---

## Level 4: The Accidental Force Push (40 points)

**Problem**: feature/payments lost 2 of 3 commits.

**Solution**:
```bash
git checkout feature/payments
git reflog
# Find the lost commit SHAs: 65c772fcbe65f989905973ea516d157e2788eab7 and b2f112b2fcddafa9de4756af6d75f4c9762c5f5a
git cherry-pick 65c772fcbe65f989905973ea516d157e2788eab7
git cherry-pick b2f112b2fcddafa9de4756af6d75f4c9762c5f5a
```

**Lost commit SHAs**:
- Payment validation: 65c772fcbe65f989905973ea516d157e2788eab7
- Payment receipt: b2f112b2fcddafa9de4756af6d75f4c9762c5f5a

**Alternative**:
```bash
git checkout feature/payments
git reset --hard b2f112b2fcddafa9de4756af6d75f4c9762c5f5a
```

**Why it works**: Git's reflog records all HEAD movements. Even after `reset --hard`, the commits still exist in the object database and can be recovered.

**Common mistakes**:
- Not knowing about `git reflog`
- Cherry-picking in wrong order
- Confusing reflog entries

---

## Level 5: The Tangled History (40 points)

**Problem**: feature/notifications has 8 messy commits.

**Solution**:
```bash
git checkout feature/notifications
git rebase -i main
# In the editor, reorganize into 2-3 commits:
# pick <first>   feat: add notification system
# squash <second> (combine related work)
# squash <third>  (combine related work)
# pick <fourth>  feat: integrate notifications with task manager
# squash <fifth> (combine related work)
# squash <sixth> (combine related work)
# pick <seventh> test: add notification config
# squash <eighth> (combine related work)
```

**Target**: 2-3 commits with conventional messages like:
- `feat: add notification system`
- `feat: integrate notifications with task manager`

**Common mistakes**:
- Not understanding pick/squash/reword
- Creating too many or too few commits
- Not using conventional commit messages

---

## Level 6: Detective — Find the Bug (60 points)

**Problem**: A subtle bug was introduced somewhere in the commit history.

**The guilty commit**: 6df8691 — "refactor: simplify task filtering logic"
**The bug**: In js/utils.js, filterByStatus() uses `!==` instead of `===`, inverting the filter.

**Solution**:
```bash
git checkout main
git bisect start
git bisect bad HEAD
git bisect good d8de9c8
git bisect run node tests/taskManager.test.js
# Bisect identifies: 6df8691
git bisect reset
git revert 6df8691
```

**Why it works**: `git bisect` performs a binary search through commits, using the test exit code to determine good/bad.

**Common mistakes**:
- Not using `git bisect run` for automation
- Manually checking each commit instead of bisecting
- Looking only at commit messages (the bug commit looks innocent)
- Being misled by red herring commits that also touch utils.js

